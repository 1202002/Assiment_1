package com.example.a1201952_todo1;

public class MultipleChoiceQuestion extends Question{
    public MultipleChoiceQuestion(String qText, String[] qOptions, int correctAnswerIdx) {
        super(qText, qOptions, correctAnswerIdx);
    }
}
